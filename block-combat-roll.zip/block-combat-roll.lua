--[[
    Block Combat Roll Script for QB-Core
    
    This script disables the combat roll animation in GTA V
    by intercepting the control input that triggers it.
]]

local QBCore = exports['qb-core']:GetCoreObject()

-- Control IDs for combat roll
local CONTROL_AIM = 25       -- INPUT_AIM (Right mouse button)
local CONTROL_JUMP = 22      -- INPUT_JUMP (Spacebar)

-- Configuration
local config = {
    enabled = true,          -- Toggle the script on/off
    notifyPlayer = true      -- Show notification when player attempts to combat roll
}

-- Main thread to disable combat roll
CreateThread(function()
    while true do
        if config.enabled then
            -- Check if player is trying to perform a combat roll
            -- Combat roll happens when pressing spacebar while aiming
            if IsControlPressed(0, CONTROL_AIM) and IsControlJustPressed(0, CONTROL_JUMP) then
                -- Disable the jump control temporarily to prevent roll
                DisableControlAction(0, CONTROL_JUMP, true)
                
                -- Optional notification
                if config.notifyPlayer then
                    QBCore.Functions.Notify("Combat roll is disabled on this server", "error", 2000)
                end
                
                -- Wait a short time before re-enabling the control
                Wait(500)
                EnableControlAction(0, CONTROL_JUMP, true)
            end
        end
        Wait(0)
    end
end)

-- Command to toggle the script (admin only)
RegisterCommand('togglecombatroll', function(source, args)
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player.PlayerData.permission == "admin" or Player.PlayerData.permission == "god" then
        config.enabled = not config.enabled
        TriggerClientEvent('QBCore:Notify', source, "Combat roll blocking is now " .. (config.enabled and "enabled" or "disabled"), "success")
    else
        TriggerClientEvent('QBCore:Notify', source, "You don't have permission to use this command", "error")
    end
end)

